import React from 'react';
import './header.css';

const header = (props) => {    

    return(
        <div className="header">
            <span>Products</span>
        </div>
    )
}
export default header;