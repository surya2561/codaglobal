export default class environment{
    static myInstance = null;
    domainUrl = 'http://localhost:3001';
    static getInstance(){
        if(environment.myInstance === null){
            environment.myInstance = new environment();
        }
        return this.myInstance;
    }

    getApi = () => {
        const api = {
             loginApi : this.domainUrl + '/api/auctionSoftware/users/login',
             registerApi: this.domainUrl + '/api/auctionSoftware/users/register',
             getProducts: this.domainUrl + '/api/auctionSoftware/users/getUserProducts'
         }
        return api;
    }
}