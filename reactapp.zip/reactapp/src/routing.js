import React from 'react';
import { Route, Switch, Redirect } from 'react-router';
import Dashboard from './container/Dashboard/dashboard'
import LandingPage from './container/LandingPage/landingpage';

const Routes = () => {
    return(
        <Switch>
        <Route exact path="/" >
        <Redirect to = '/login-register'/>
        </Route>
        <Route exact path='/login-register' component={Dashboard}/>
        <Route exact path='/home/dashboard' component={LandingPage}/>

        <Route component = {()=> {
            return <div> No Path Found </div>
        }
        }/>
        </Switch>
    )
}

export default Routes;