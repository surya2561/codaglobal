import React, {Component} from 'react';
import axios from 'axios';
import environment from '../../environment';
import ProductPagination from '../../components/Pagination/ProductPagination/productPagination';
const environmentService = new environment();

class LandingPage extends Component{
    constructor(props){
        super(props);
        this.state = {
            id: props.id,
            productData: {}
        }
    }
    componentDidMount(){
        axios.get(environmentService.getApi().getProducts, {params: {id: 1}})
        .then(success => {
            console.log(success);
            this.setState({
                productData: success.data.products
            })
        })
    }
    render(){
        return(
            <div class="landing-page">
                <ProductPagination product={this.state.productData}/>
            </div>
        )
    }
}

export default LandingPage;