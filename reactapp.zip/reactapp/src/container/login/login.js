import React, {Component} from 'react';
import axios from 'axios';
import './login.css';
import environment from '../../environment';
import Input from '../../components/Input/input';

const environmentService = new environment();
class Login extends Component {
  constructor(props){
    super(props);
    this.state = {
      'email' : null,
      'psw': null,
    }
    this.inputChangeHandler = this.inputChangeHandler.bind(this);
  }

 inputChangeHandler = (event) => {
   const target = event.target;
   const value = target.value;
   const name = target.name;
   this.setState({
     [name]: value
   })
 }

 formValues = () => {
   
  this.props.props.history.push('/home/dashboard')
   if(this.state.email && this.state.psw) {

    this.setState({
      errorMessage: null
    })
    axios.post(environmentService.getApi().loginApi, {email: this.state.email, password: this.state.psw})
    .then(success => {
      if(success.data.msg === 'Login successs'){
        this.props.props.history.push('/home/dashboard')
      } 
    })
   }
 }

 render() {
    return (
      <div className="login-form">
        <div className="login">
          <form>
          <div className="container">
          <h1>Login</h1>
          <hr/>

          <Input input_type="input" label="Email" type="email" placeholder="Enter Email" name="email" id="email" change={this.inputChangeHandler}/>   
          <Input input_type="input" label="Password" type="password" placeholder="Enter Password" name="psw" id="psw" change={this.inputChangeHandler}/>   
          <hr/>
           <button type="button" className="registerbtn" onClick={ this.formValues  }>Login</button>
          </div>
          </form>
        </div>
        </div>
    )
  }
}

export default Login;