import React, { Component } from 'react';
import './register.css';
import axios from 'axios'
import environment from '../../environment';
import Input from '../../components/Input/input';
const environmentService = new environment();
class Register extends Component {
    constructor(props){
        super(props);
        this.state = {
            fields: {},
        }
        this.inputChangeHandler = this.inputChangeHandler.bind(this);
    }
  
    inputChangeHandler = (fieldName, event) => {
        let fields = this.state.fields;
        fields[fieldName] =  event.target.value
        this.setState({fields});
    }

 
    submitForm = (event) => {
            axios({
                url: environmentService.getApi().registerApi,
                method: 'POST',
                data: this.state.fields,
            })
            .then(success => {
                alert(success.data.msg);
            })
    }

  

    render(){
        return(
            <div className = "register-form" >
            <div className="register">
            <form autoComplete="off">
                  
                  <div className="container">
                  <p>Please fill in this form to add a user.</p>
                  <hr/>

                  <Input input_type="input" label="FirstName" type="text" placeholder="Enter FirstName" name="firstName" id="firstName" change={this.inputChangeHandler.bind(this, 'firstName')}/>   
                 
                 
                  <Input input_type="input" label="Email" type="email" placeholder="Enter Email" name="email" id="email" change={this.inputChangeHandler.bind(this, 'email')}/>
                  

                  <Input input_type="input" label="Password" type="password" placeholder="Enter Password" name="password" id="psw" change={this.inputChangeHandler.bind(this, 'password')}/>
                  
                 <hr/>
                  <button type="button" className="registerbtn" onClick={this.submitForm.bind(this)}>Register</button>
                  </div>
            </form>
            </div>
            </div>
        )
    }
}

export default Register;