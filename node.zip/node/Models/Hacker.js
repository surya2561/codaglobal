const mongoose = require('mongoose');

const hackerSchema = mongoose.Schema({
    team_name: { type: String, required: true, default: null },
    wins: { type: Number, required: true, default: null},
    lose: { type: Number, required: true, default: null},
    ties: { type: Number, required: true, default: null},
    score: { type: Number, required: true, default: null}

})

module.exports = mongoose.model('Hacker', hackerSchema)