const { asyncMiddleWare } = require('../Delegates/asyncMiddleware');
const Hacker = require('../Models/Hacker');
const router = require('express').Router();

router.post('/addteams', asyncMiddleWare(async(req, res) => {
    Hacker.insertMany(
        req.body.teams
    )
    .then(success => {
        console.log(success);
        res.status(200).json({message: 'Data gets inserted'})
    })
}))

router.get('/getTeams', asyncMiddleWare(async(req, res)=> {
    Hacker.find()
    .sort({'score': -1})
    .then(data => {
        res.status(200).json({"teams": data});
    })
}))

router.post('/saveResult', asyncMiddleWare(async(req, res)=> {
    const query = {team_name: req.body.team_name};
    const score = req.body.type == 'winner'? 10 : req.body.type == 'lose' ? 5 : 0;
    Hacker.updateOne(query, {$set : {score: score}}).then(success => {
        res.status(200).json({message: 'Result got saved'});
    })
}))
module.exports = router;