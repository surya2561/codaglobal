const mysql = require('mysql2');
const mysqlDBConnection = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Suri@1134',
    database: 'auctionsoftware'
})
.promise()

module.exports = { mysqlDBConnection };