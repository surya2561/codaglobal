const express = require('express');
const errorHandling = require('./Utils/errorHandling');
const app = express();
const headerConfig = require('./Utils/headerConfig');
const hacker = require('./Controllers/Hacker');
const mongoose = require('mongoose');
app.use(express.json());
app.use(express.urlencoded({ extended: true}));
app.use(headerConfig);

app.use('/api/codaglobal/contest', hacker);
app.use(errorHandling);

const port = 3000 || process.env.port;

app.listen(port, () => {
  console.log('server listening at ' + port);
});

mongoose.connect('mongodb://localhost/Task', {useUnifiedTopology: true, useNewUrlParser: true})
.then(success=>{
    console.log('Connected to mongodb');
})
.catch(error => {
  console.log(error);
})