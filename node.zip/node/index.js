const express = require('express');
const errorHandling = require('./Utils/errorHandling');
const app = express();
const headerConfig = require('./Utils/headerConfig');
const user = require('./Controllers/User');
app.use(express.json());
app.use(express.urlencoded({ extended: true}));
app.use(headerConfig);

app.use('/api/auctionSoftware/users', user);
app.use(errorHandling);

const port = 3001;

app.listen(port, () => {
  console.log('server listening at ' + port);
});
